package com.example.myfoodapp.model;

public class Choose_type_Adapter {
}
