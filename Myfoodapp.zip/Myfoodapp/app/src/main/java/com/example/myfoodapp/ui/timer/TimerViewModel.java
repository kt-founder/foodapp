package com.example.myfoodapp.ui.timer;

import androidx.lifecycle.ViewModel;

public class TimerViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}