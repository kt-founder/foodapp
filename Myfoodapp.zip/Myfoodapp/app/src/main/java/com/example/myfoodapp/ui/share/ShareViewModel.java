package com.example.myfoodapp.ui.share;

import androidx.lifecycle.ViewModel;

public class ShareViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}